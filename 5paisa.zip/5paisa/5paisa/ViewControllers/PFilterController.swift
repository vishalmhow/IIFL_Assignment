//
//  PFilterController.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 20/02/22.
//

import UIKit
protocol PFilterControllerDelegate:AnyObject {
    func applyFilterAndSort(_ filterArray: [String], sort: String)
}
class PFilterController: UIViewController {
    @IBOutlet weak var filtterTableView: UITableView!
    @IBOutlet weak var sortTableView: UITableView!
    var viewModel = PFilterViewModel()
    weak var delegate: PFilterControllerDelegate?


    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Filters"
        let applyButton = UIBarButtonItem(title: "Apply", style: .plain, target: self, action: #selector(applyButtonTapped))
        self.navigationItem.rightBarButtonItem = applyButton

    }
    
    @objc func applyButtonTapped() {
        self.viewModel.selectedFilters.removeAll()
        self.viewModel.selectedSort.removeAll()
        
        if let selectedRows = filtterTableView.indexPathsForSelectedRows {
            for ipath in selectedRows {
                self.viewModel.selectedFilters.append(self.viewModel.filterArray[ipath.row])
            }
        }
        if let selectedRow = sortTableView.indexPathsForSelectedRows {
            for ipath in selectedRow {
                self.viewModel.selectedSort = self.viewModel.sortArray[ipath.row]
            }
        }
        self.navigationController?.popViewController(animated: true)
        delegate?.applyFilterAndSort(self.viewModel.selectedFilters, sort: self.viewModel.selectedSort)
       
    }
    
}
extension PFilterController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.filtterTableView{
            return self.viewModel.filterArray.count
        } else {
            return self.viewModel.sortArray.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        if tableView == self.filtterTableView{
            cell.textLabel?.text = self.viewModel.filterArray[indexPath.row]
        } else {
            cell.textLabel?.text = self.viewModel.sortArray[indexPath.row]
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == self.filtterTableView {
            self.filtterTableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
        } else {
            self.sortTableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
        }
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if tableView == self.filtterTableView {
            self.filtterTableView.cellForRow(at: indexPath)?.accessoryType = .none
        } else {
            self.sortTableView.cellForRow(at: indexPath)?.accessoryType = .none
        }
    }
}
