//
//  PSplashScreen.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 18/02/22.
//

import Foundation
import AVKit
import AVFoundation

class PSplashScreenContoller: UIViewController {
    
    let playerController = AVPlayerViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        playVideo()
    }
    
    private func playVideo() {
        playerController.view.backgroundColor = UIColor(red: 139/255, green: 26/255, blue: 56/255, alpha: 1)
        // Making sure that our video will found in the path
        guard let path = Bundle.main.path(forResource: "splash_file", ofType: "mp4") else {
            debugPrint("splash_file.m4v not found")
            return
        }
        let player = AVPlayer(url: URL(fileURLWithPath: path))
        // Defining Video
        playerController.showsPlaybackControls = false
        playerController.player = player
        playerController.videoGravity = .resizeAspectFill
        // This notification will detect if video is finished
        NotificationCenter.default.addObserver(self, selector: #selector(playerDidFinishPlaying), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: playerController.player?.currentItem)
        // Playing Video
        present(playerController, animated: false) {
            player.play()
        }
    }
    // MARK: - Checking if video is finished
    @objc func playerDidFinishPlaying(note: NSNotification) {
        guard let loginViewController = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "PLoginViewController") as? PLoginViewController else {
            return
        }
        self.navigationController?.pushViewController(loginViewController, animated: false)
        playerController.dismiss(animated: false, completion: nil)
    }
}
