//
//  PDashboardViewController.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 18/02/22.
//

import UIKit
import AVFoundation

class PDashboardViewController: UIViewController {
    var timer = Timer()
    @IBOutlet weak var schemeTableView: UITableView!
    var viewModel = PDashboardViewModel()
  //  private let slidingTabController = PSlideTabController()
    let refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupViewProperties()
    }
    
    func setupViewProperties() {
        self.title = "Schemes"
        self.fetchSchemes()
        self.timer = Timer.scheduledTimer(withTimeInterval: 1800, repeats: true, block: { _ in
            self.viewModel.schaduledToFetchSchemes(isSchaduled: true) { status in
                DispatchQueue.main.async {
                    self.schemeTableView.reloadData()
                }
            }
        })
        
        let filterButton = UIBarButtonItem(title: "Filter", style: .plain, target: self, action: #selector(filterButtonTapped))
        self.navigationItem.leftBarButtonItem = filterButton
        let logoutButton = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logoutButtonTapped))
        self.navigationItem.rightBarButtonItem = logoutButton
        
        /*refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
           refreshControl.addTarget(self, action: #selector(self.refreshSchemes(_:)), for: .valueChanged)
        self.schemeTableView.addSubview(refreshControl)*/
    }
    @objc func refreshSchemes(_ sender: AnyObject) {
       // Code to refresh table view
        self.timer.invalidate()
        self.viewModel.schaduledToFetchSchemes(isSchaduled: true) { status in
            DispatchQueue.main.async {
                self.refreshControl.endRefreshing()
                self.schemeTableView.reloadData()
            }
        }
//        self.timer = Timer.scheduledTimer(withTimeInterval: 1800, repeats: true, block: { _ in
//            self.viewModel.schaduledToFetchSchemes(isSchaduled: true) { status in
//                DispatchQueue.main.async {
//                    self.refreshControl.endRefreshing()
//                    self.schemeTableView.reloadData()
//                }
//            }
//        })
    }
    
    func fetchSchemes() {
        self.viewModel.fetchSchemes { status in
            if status {
                DispatchQueue.main.async {
                    self.schemeTableView.reloadData()
                }
            }
        }
    }
   @objc func filterButtonTapped() {
       let alert = UIAlertController(title: "Sort & Filter", message: "Please Select an Option", preferredStyle: .actionSheet)
           
       if !self.viewModel.selectedSort.isEmpty || !self.viewModel.selectedFilters.isEmpty {
           alert.addAction(UIAlertAction(title: "Clear Filter", style: .default , handler:{ (UIAlertAction)in
               self.showSortOptions()
           }))
       }
           alert.addAction(UIAlertAction(title: "Filter", style: .default , handler:{ (UIAlertAction)in
               self.openFilterController()
           }))
       alert.addAction(UIAlertAction(title: "Cancel", style: .destructive , handler:{ (UIAlertAction)in
       }))
           self.present(alert, animated: true, completion: {
               print("completion block")
           })
    }
    
    func showSortOptions() {
        self.fetchSchemes()
    }
    
    func openFilterController() {
        guard let filterController = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "PFilterController") as? PFilterController else {
            return
        }
        filterController.delegate = self
        self.navigationController?.pushViewController(filterController, animated: false)
    }

    @objc func logoutButtonTapped() {
        self.timer.invalidate()
        self.navigationController?.popViewController(animated: false)
     }
    
   /* private func setupUI(){
        // view
        view.backgroundColor = .white
        view.addSubview(slidingTabController.view) // add slidingTabController to main view
        
        // navigation
        navigationItem.title = ""
        navigationController?.navigationBar.barTintColor = .orange
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.barStyle = .`default`
        navigationController?.navigationBar.backgroundColor = .orange
        
        // MARK: slidingTabController
        slidingTabController.addItem(item: PSchemsListViewController(), title: "First") // add first item
       // slidingTabController.addItem(item: PSchemsListViewController(), title: "Second") // add second item
       // slidingTabController.addItem(item: PSchemsListViewController(), title: "Third") // add other item
        slidingTabController.setHeaderActiveColor(color: .white) // default blue
        slidingTabController.setHeaderInActiveColor(color: .lightText) // default gray
        slidingTabController.setHeaderBackgroundColor(color: .orange) // default white
        slidingTabController.setCurrentPosition(position: 0) // default 0
        slidingTabController.setStyle(style: .flexible) // default fixed
        slidingTabController.build() // build
    }*/
}

extension PDashboardViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.schemeList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? PSchemeCell else {
            return UITableViewCell()
        }
        cell.configureSummary(schemeModel: self.viewModel.schemeList[indexPath.row])
        
        return cell
    }
}

extension PDashboardViewController: PFilterControllerDelegate {
    func applyFilterAndSort(_ filterArray: [String], sort: String) {
        if sort.isEmpty && filterArray.isEmpty {
            return
        }
        self.viewModel.selectedFilters = filterArray
        self.viewModel.selectedSort = sort
        self.viewModel.filterAndSortData(filterArray, sort: sort) { status in
            DispatchQueue.main.async {
                self.schemeTableView.reloadData()
            }
        }
    }
}
