//
//  PDashboardViewModel.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 19/02/22.
//

import Foundation
import CoreData

class PDashboardViewModel: NSObject {
    let repository = PWebServiceManager(apiClient: APIClient())
    var markedVitalArray: SchemesResponseModel?
    let persistence = PPersistenceService.shared
    var schemeList = [SchemesEntity]()
    var selectedFilters = [""]
    var selectedSort = ""
    
    func getSchemeList(completion: @escaping((Bool) -> Void)) {
        repository.getSchemes { response in
            self.markedVitalArray = response
            self.persistence.removeAllData("SchemesEntity")
            self.saveSchemes(schemeData: self.markedVitalArray?.response.data.schemelist.scheme ?? []) { _ in
                completion(true)
            }
        } failure: { error in
            print(error!)
        }
    }
    
    func saveSchemes(schemeData: [SchemeData], completion: @escaping((Bool) -> Void)) {
        if schemeData.isEmpty {
            return
        }
        _ = schemeData.compactMap { obj -> SchemesEntity in
            let aum = obj.aum
            let amccode = obj.amccode
            let mfSchcode = obj.mfSchcode
            let schemeName = obj.schemeName
            let mainCode = obj.mainCode
            let schemeCategory = obj.schemeCategory
            let oneYear = obj.oneYear
            let threeYear = obj.threeYear
            let fiveYear = obj.fiveYear
            let inception = obj.inception
            let nav = obj.nav
            let perChange = obj.perChange
            let riskometervalue = obj.riskometervalue
            let recommenedFundFlag = obj.recommenedFundFlag
            let morningstaroverall = obj.morningstaroverall
            let subscriptionFlag = obj.subscriptionFlag
            let investment = obj.investment
            let groupCode = obj.groupCode
            let isin = obj.isin
            
            let scheme = SchemesEntity(context: self.persistence.context)
            scheme.aum = aum
            scheme.amccode = amccode
            scheme.fiveYear = fiveYear
            scheme.groupCode = groupCode
            scheme.inception = inception
            scheme.investment = investment
            scheme.isin = isin
            scheme.mainCode = mainCode
            scheme.mf_schcode = mfSchcode
            scheme.morningstaroverall = morningstaroverall
            scheme.nav = nav
            scheme.oneYear = oneYear
            scheme.perChange = perChange
            scheme.recommenedFundFlag = recommenedFundFlag
            scheme.riskometervalue = riskometervalue
            scheme.schemeCategory = schemeCategory
            scheme.schemeName = schemeName
            scheme.subscriptionFlag = subscriptionFlag
            scheme.threeYear = threeYear
            return scheme
        }
        self.persistence.save()
        completion(true)
    }
    
    func fetchSchemes(completion: @escaping((Bool) -> Void)) {
        if self.schemeList.isEmpty {
            self.getSchemeList { status in
                if status {
                    self.persistence.fetchData(SchemesEntity.self) { (schemeList) in
                        self.schemeList = []
                        self.schemeList = schemeList
                        completion(true)
                    }
                }
            }
        } else {
            self.persistence.fetchData(SchemesEntity.self) { (schemeList) in
                self.schemeList = []
                self.schemeList = schemeList
                completion(true)
            }
        }

    }
    func schaduledToFetchSchemes(isSchaduled: Bool, completion: @escaping((Bool) -> Void)) {
        self.getSchemeList { status in
            if status {
                self.persistence.fetchData(SchemesEntity.self) { (schemeList) in
                    self.schemeList = []
                    self.schemeList = schemeList
                    completion(true)
                }
            }
    }
    }
    //    FIlter :  Riskometer value -> Very High, Recommended Fund Flag -> Y (multiple filters can be applied)
    //    Sort: NAV (desc), PerChange(desc),  AUM(desc) - one at a time
    func filterAndSortData(_ filterArray: [String], sort: String, completion: @escaping((Bool) -> Void)) {
        print(self.schemeList)

        completion(true)
    }
}
