//
//  PFilterViewModel.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 20/02/22.
//

import Foundation

class PFilterViewModel: NSObject {
    
    var filterArray = ["Riskometer value", "Recommended Fund"]
    var sortArray = ["NAV (desc)", "PerChange(desc)", "AUM(desc)"]
    var selectedFilters = [""]
    var selectedSort = ""
}
