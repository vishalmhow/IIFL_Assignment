//
//  SchemesEntity+CoreDataProperties.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 19/02/22.
//
//

import Foundation
import CoreData


extension SchemesEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<SchemesEntity> {
        return NSFetchRequest<SchemesEntity>(entityName: "SchemesEntity")
    }

    @NSManaged public var amccode: String?
    @NSManaged public var aum: String?
    @NSManaged public var fiveYear: String?
    @NSManaged public var groupCode: String?
    @NSManaged public var inception: String?
    @NSManaged public var investment: String?
    @NSManaged public var isin: String?
    @NSManaged public var mainCode: String?
    @NSManaged public var mf_schcode: String?
    @NSManaged public var morningstaroverall: String?
    @NSManaged public var nav: String?
    @NSManaged public var oneYear: String?
    @NSManaged public var perChange: String?
    @NSManaged public var recommenedFundFlag: String?
    @NSManaged public var riskometervalue: String?
    @NSManaged public var schemeCategory: String?
    @NSManaged public var schemeName: String?
    @NSManaged public var subscriptionFlag: String?
    @NSManaged public var threeYear: String?

}

extension SchemesEntity : Identifiable {

}
